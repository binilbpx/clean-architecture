﻿using CleanArchitecture.Core.Entites;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanArchitecture.Application.Interfaces
{
    public interface IMetadataRepository : IRepository<Metadata>
    {
    }
}
